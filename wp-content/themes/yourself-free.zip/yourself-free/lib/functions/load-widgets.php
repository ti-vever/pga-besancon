<?php
/* Recent */
require_once(TEMPLATEPATH . '/lib/widgets/widget-recent.php');
/* 300*250 Ad */
require_once(TEMPLATEPATH . '/lib/widgets/widget-ad-300-250.php');
/* 125*125 Ads */
require_once(TEMPLATEPATH . '/lib/widgets/widget-ads-125.php');
/* Login Form */
require_once(TEMPLATEPATH . '/lib/widgets/widget-login.php');
/* Contact Form */
require_once(TEMPLATEPATH . '/lib/widgets/widget-contact.php');
/* Flickr */
require_once(TEMPLATEPATH . '/lib/widgets/widget-flickr.php');
/* Screenshot */
require_once(TEMPLATEPATH . '/lib/widgets/widget-screenshot.php');
/* Video */
require_once(TEMPLATEPATH . '/lib/widgets/widget-video.php');
/* Tabs */
require_once(TEMPLATEPATH . '/lib/widgets/widget-tabs.php');
/* Featured Post */
require_once(TEMPLATEPATH . '/lib/widgets/widget-featured.php');
/* Posts Slider */
require_once(TEMPLATEPATH . '/lib/widgets/widget-posts-slider.php');
?>